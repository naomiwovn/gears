#!/usr/bin/env python

#
# NopSCADlib Copyright Chris Palmer 2018
# nop.head@gmail.com
# hydraraptor.blogspot.com
#
# This file is part of NopSCADlib.
#
# NopSCADlib is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License as published by the Free Software Foundation, either version 3 of
# the License, or (at your option) any later version.
#
# NopSCADlib is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with NopSCADlib.
# If not, see <https://www.gnu.org/licenses/>.
#
#! Generates DXF files for all the routed parts listed on the BOM or a specified list.
#
from __future__ import print_function
import sys

from exports import make_parts

if __name__ == '__main__':
    if len(sys.argv) > 1 and not '.' in sys.argv[1]:
        target, parts = sys.argv[1], sys.argv[2:]
    else:
        target, parts = None, sys.argv[1:]
    make_parts(target, 'dxf', parts)
